import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sun, CloudSun, Cloud, Home, Fence, TreePine, Sprout, Award, ArrowRight, ArrowLeft } from "lucide-react";
import type { QuizAnswers, LightLevel, SpaceType, ExperienceLevel } from "@/data/plants";

interface QuizStep {
  id: keyof QuizAnswers;
  question: string;
  subtitle: string;
  options: { value: string; label: string; description: string; icon: React.ReactNode }[];
}

const steps: QuizStep[] = [
  {
    id: "light",
    question: "How much natural light does your space get?",
    subtitle: "Think about where you'd put the plant during the day.",
    options: [
      { value: "low", label: "Low light", description: "No direct sun, north-facing windows or interior rooms", icon: <Cloud className="h-6 w-6" /> },
      { value: "medium", label: "Medium light", description: "Indirect sunlight, east or west-facing windows", icon: <CloudSun className="h-6 w-6" /> },
      { value: "bright", label: "Bright light", description: "Lots of direct sun, south-facing windows or balcony", icon: <Sun className="h-6 w-6" /> },
    ],
  },
  {
    id: "space",
    question: "Where will your plant live?",
    subtitle: "Pick the spot that best describes your setup.",
    options: [
      { value: "indoor", label: "Indoor", description: "Living room, bedroom, bathroom, or office", icon: <Home className="h-6 w-6" /> },
      { value: "balcony", label: "Balcony", description: "Covered or open balcony, terrace, or patio", icon: <Fence className="h-6 w-6" /> },
      { value: "outdoor", label: "Outdoor", description: "Garden, yard, or open outdoor area", icon: <TreePine className="h-6 w-6" /> },
    ],
  },
  {
    id: "experience",
    question: "How experienced are you with plants?",
    subtitle: "Be honest — we won't judge! This helps us find the right fit.",
    options: [
      { value: "beginner", label: "Beginner", description: "I'm new to plants or have killed a few (it's okay!)", icon: <Sprout className="h-6 w-6" /> },
      { value: "intermediate", label: "Some experience", description: "I've kept a few plants alive and want to grow my collection", icon: <Award className="h-6 w-6" /> },
    ],
  },
];

export default function QuizPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<QuizAnswers>>({});

  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  function selectOption(value: string) {
    const updated = { ...answers, [step.id]: value };
    setAnswers(updated);

    if (currentStep < steps.length - 1) {
      setTimeout(() => setCurrentStep(currentStep + 1), 300);
    } else {
      const params = new URLSearchParams(updated as Record<string, string>);
      navigate(`/results?${params.toString()}`);
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12">
      <div className="container max-w-2xl">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>Question {currentStep + 1} of {steps.length}</span>
            {currentStep > 0 && (
              <button
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex items-center gap-1 text-primary hover:underline active:scale-95"
              >
                <ArrowLeft className="h-3 w-3" /> Back
              </button>
            )}
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full rounded-full bg-primary transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="text-center mb-10 animate-fade-in" key={currentStep}>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">{step.question}</h1>
          <p className="text-muted-foreground">{step.subtitle}</p>
        </div>

        {/* Options */}
        <div className="grid gap-4" key={`options-${currentStep}`}>
          {step.options.map((option, i) => {
            const selected = answers[step.id] === option.value;
            return (
              <button
                key={option.value}
                onClick={() => selectOption(option.value)}
                className={`flex items-center gap-4 p-5 rounded-2xl border-2 text-left transition-all duration-200 active:scale-[0.98] animate-slide-up ${
                  selected
                    ? "border-primary bg-primary/5 shadow-md"
                    : "border-border hover:border-primary/40 hover:bg-card hover:shadow-sm"
                }`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl transition-colors ${
                    selected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {option.icon}
                </div>
                <div>
                  <div className="font-semibold text-foreground">{option.label}</div>
                  <div className="text-sm text-muted-foreground">{option.description}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
