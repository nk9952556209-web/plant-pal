import { Link } from "react-router-dom";
import { Droplets, CheckCircle2, AlertCircle, Trash2, Leaf, Plus } from "lucide-react";
import { useSavedPlants } from "@/hooks/useSavedPlants";
import { plants } from "@/data/plants";
import { useScrollReveal } from "@/hooks/useScrollReveal";

function getDaysSince(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const diff = Date.now() - new Date(dateStr).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export default function DashboardPage() {
  const { savedPlants, removePlant, markWatered } = useSavedPlants();
  const reveal = useScrollReveal();

  const gardenPlants = savedPlants
    .map((sp) => {
      const plant = plants.find((p) => p.id === sp.plantId);
      if (!plant) return null;
      const daysSinceWatered = getDaysSince(sp.lastWatered);
      const needsWater = daysSinceWatered === null || daysSinceWatered >= plant.waterDays;
      return { ...sp, plant, daysSinceWatered, needsWater };
    })
    .filter(Boolean) as {
    plantId: string;
    plant: (typeof plants)[0];
    lastWatered: string | null;
    daysSinceWatered: number | null;
    needsWater: boolean;
    tasksCompleted: string[];
  }[];

  return (
    <div className="py-12">
      <div className="container max-w-4xl">
        <div
          ref={reveal.ref}
          className={`mb-10 ${reveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-2">My Garden</h1>
          <p className="text-muted-foreground">
            Track and care for your saved plants.
          </p>
        </div>

        {gardenPlants.length === 0 ? (
          <div className="text-center py-20 space-y-4">
            <div className="mx-auto h-16 w-16 rounded-2xl bg-muted flex items-center justify-center">
              <Leaf className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold">Your garden is empty</h2>
            <p className="text-muted-foreground max-w-sm mx-auto">
              Find your first plant by taking our recommendation quiz or browsing the catalog.
            </p>
            <div className="flex justify-center gap-3">
              <Link
                to="/quiz"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium shadow-sm hover:shadow-md transition-all active:scale-[0.97]"
              >
                <Plus className="h-4 w-4" /> Find a Plant
              </Link>
              <Link
                to="/catalog"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors active:scale-[0.97]"
              >
                Browse Catalog
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Summary */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
              <div className="p-5 rounded-2xl bg-card border border-border/60 text-center">
                <p className="text-3xl font-bold text-primary">{gardenPlants.length}</p>
                <p className="text-sm text-muted-foreground">Plants</p>
              </div>
              <div className="p-5 rounded-2xl bg-card border border-border/60 text-center">
                <p className="text-3xl font-bold text-success">
                  {gardenPlants.filter((p) => !p.needsWater).length}
                </p>
                <p className="text-sm text-muted-foreground">Healthy</p>
              </div>
              <div className="p-5 rounded-2xl bg-card border border-border/60 text-center col-span-2 md:col-span-1">
                <p className="text-3xl font-bold text-warning">
                  {gardenPlants.filter((p) => p.needsWater).length}
                </p>
                <p className="text-sm text-muted-foreground">Need attention</p>
              </div>
            </div>

            {/* Plant list */}
            <div className="space-y-4">
              {gardenPlants.map((item, i) => (
                <div
                  key={item.plantId}
                  className={`flex items-center gap-4 p-4 rounded-2xl bg-card border border-border/60 transition-all duration-200 hover:shadow-sm animate-scale-in`}
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <Link to={`/plant/${item.plant.id}`} className="shrink-0">
                    <img
                      src={item.plant.image}
                      alt={item.plant.name}
                      className="h-16 w-16 rounded-xl object-cover"
                    />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/plant/${item.plant.id}`} className="font-semibold text-foreground hover:text-primary transition-colors">
                      {item.plant.name}
                    </Link>
                    <div className="flex items-center gap-2 mt-1">
                      {item.needsWater ? (
                        <span className="flex items-center gap-1 text-xs text-warning font-medium">
                          <AlertCircle className="h-3 w-3" />
                          Needs watering
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs text-success font-medium">
                          <CheckCircle2 className="h-3 w-3" />
                          Healthy
                        </span>
                      )}
                      {item.daysSinceWatered !== null && (
                        <span className="text-xs text-muted-foreground">
                          · Watered {item.daysSinceWatered === 0 ? "today" : `${item.daysSinceWatered}d ago`}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => markWatered(item.plantId)}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 text-blue-600 text-xs font-medium hover:bg-blue-100 transition-colors active:scale-95"
                    >
                      <Droplets className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Water</span>
                    </button>
                    <button
                      onClick={() => removePlant(item.plantId)}
                      className="p-2 rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors active:scale-95"
                      title="Remove plant"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
