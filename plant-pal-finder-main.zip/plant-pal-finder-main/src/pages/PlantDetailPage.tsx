import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Droplets, Sun, ThermometerSun, Shovel, AlertTriangle, TrendingUp, Heart, HeartOff } from "lucide-react";
import { plants } from "@/data/plants";
import { useSavedPlants } from "@/hooks/useSavedPlants";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const difficultyColor = {
  easy: "bg-green-100 text-green-800",
  medium: "bg-amber-100 text-amber-800",
  hard: "bg-red-100 text-red-800",
};

export default function PlantDetailPage() {
  const { id } = useParams<{ id: string }>();
  const plant = plants.find((p) => p.id === id);
  const { isPlantSaved, savePlant, removePlant } = useSavedPlants();
  const reveal = useScrollReveal();

  if (!plant) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center space-y-3">
          <p className="text-lg text-muted-foreground">Plant not found</p>
          <Link to="/catalog" className="text-primary hover:underline text-sm">
            ← Back to catalog
          </Link>
        </div>
      </div>
    );
  }

  const saved = isPlantSaved(plant.id);

  const careItems = [
    { icon: Droplets, label: "Watering", content: plant.careInstructions.watering, color: "text-blue-500" },
    { icon: Sun, label: "Sunlight", content: plant.careInstructions.sunlight, color: "text-amber-500" },
    { icon: Shovel, label: "Soil", content: plant.careInstructions.soil, color: "text-soil" },
    { icon: ThermometerSun, label: "Temperature", content: plant.careInstructions.temperature, color: "text-red-400" },
  ];

  return (
    <div className="py-8 md:py-12">
      <div className="container max-w-4xl">
        <Link
          to="/catalog"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" /> Back to catalog
        </Link>

        <div
          ref={reveal.ref}
          className={`${reveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
        >
          {/* Hero */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="aspect-square rounded-2xl overflow-hidden bg-muted">
              <img
                src={plant.image}
                alt={plant.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="space-y-4 flex flex-col justify-center">
              <div>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium capitalize mb-3 ${difficultyColor[plant.difficulty]}`}>
                  {plant.difficulty} care
                </span>
                <h1 className="text-3xl md:text-4xl font-bold leading-tight">{plant.name}</h1>
                <p className="text-muted-foreground italic">{plant.botanicalName}</p>
              </div>
              <p className="text-foreground/80">{plant.description}</p>
              <div className="flex flex-wrap gap-2">
                {plant.tags.map((tag) => (
                  <span key={tag} className="px-2.5 py-1 rounded-lg bg-muted text-xs text-muted-foreground">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => (saved ? removePlant(plant.id) : savePlant(plant.id))}
                  className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 active:scale-[0.97] ${
                    saved
                      ? "bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20"
                      : "bg-primary text-primary-foreground shadow-sm hover:shadow-md"
                  }`}
                >
                  {saved ? <HeartOff className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
                  {saved ? "Remove from Garden" : "Add to My Garden"}
                </button>
              </div>
            </div>
          </div>

          {/* Care Instructions */}
          <div className="space-y-6 mb-12">
            <h2 className="text-2xl font-bold">Care Guide</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {careItems.map((item) => (
                <div key={item.label} className="p-5 rounded-2xl bg-card border border-border/60 space-y-2">
                  <div className="flex items-center gap-2">
                    <item.icon className={`h-5 w-5 ${item.color}`} />
                    <h3 className="font-semibold">{item.label}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">{item.content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Common Mistakes */}
          <div className="space-y-4 mb-12">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              Common Mistakes
            </h2>
            <div className="space-y-3">
              {plant.commonMistakes.map((mistake, i) => (
                <div key={i} className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 border border-amber-200/60">
                  <span className="text-warning font-bold text-sm mt-0.5">!</span>
                  <p className="text-sm text-foreground/80">{mistake}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Growth */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Growth Expectations
            </h2>
            <p className="text-muted-foreground p-5 rounded-2xl bg-card border border-border/60">
              {plant.growthExpectations}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
