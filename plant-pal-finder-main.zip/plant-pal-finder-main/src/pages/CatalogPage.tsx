import { useState, useMemo } from "react";
import { Search, Filter } from "lucide-react";
import { plants, type LightLevel, type Difficulty } from "@/data/plants";
import PlantCard from "@/components/PlantCard";
import { useScrollReveal } from "@/hooks/useScrollReveal";

type SpaceFilter = "all" | "indoor" | "balcony" | "outdoor";
type LightFilter = "all" | LightLevel;
type DifficultyFilter = "all" | Difficulty;

export default function CatalogPage() {
  const reveal = useScrollReveal();
  const [search, setSearch] = useState("");
  const [light, setLight] = useState<LightFilter>("all");
  const [space, setSpace] = useState<SpaceFilter>("all");
  const [difficulty, setDifficulty] = useState<DifficultyFilter>("all");

  const filtered = useMemo(() => {
    return plants.filter((p) => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (light !== "all" && p.lightRequirement !== light) return false;
      if (space !== "all" && !p.suitableSpace.includes(space as any)) return false;
      if (difficulty !== "all" && p.difficulty !== difficulty) return false;
      return true;
    });
  }, [search, light, space, difficulty]);

  const filterBtn = (active: boolean) =>
    `px-3 py-1.5 rounded-lg text-sm font-medium transition-colors duration-150 active:scale-95 ${
      active ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:text-foreground"
    }`;

  return (
    <div className="py-12">
      <div className="container">
        <div
          ref={reveal.ref}
          className={`mb-10 ${reveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Plant Catalog</h1>
          <p className="text-muted-foreground">
            Browse our curated collection of {plants.length} beginner-friendly plants.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="space-y-4 mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search plants..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border bg-card text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-shadow"
            />
          </div>

          <div className="flex flex-wrap gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Light</label>
              <div className="flex gap-1.5">
                {(["all", "low", "medium", "bright"] as LightFilter[]).map((v) => (
                  <button key={v} onClick={() => setLight(v)} className={filterBtn(light === v)}>
                    {v === "all" ? "All" : v.charAt(0).toUpperCase() + v.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Space</label>
              <div className="flex gap-1.5">
                {(["all", "indoor", "balcony", "outdoor"] as SpaceFilter[]).map((v) => (
                  <button key={v} onClick={() => setSpace(v)} className={filterBtn(space === v)}>
                    {v === "all" ? "All" : v.charAt(0).toUpperCase() + v.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Difficulty</label>
              <div className="flex gap-1.5">
                {(["all", "easy", "medium", "hard"] as DifficultyFilter[]).map((v) => (
                  <button key={v} onClick={() => setDifficulty(v)} className={filterBtn(difficulty === v)}>
                    {v === "all" ? "All" : v.charAt(0).toUpperCase() + v.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filtered.map((plant, i) => (
              <div key={plant.id} className="animate-scale-in" style={{ animationDelay: `${i * 60}ms` }}>
                <PlantCard plant={plant} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-lg text-muted-foreground">No plants match your filters.</p>
            <button
              onClick={() => { setSearch(""); setLight("all"); setSpace("all"); setDifficulty("all"); }}
              className="mt-3 text-sm text-primary hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
