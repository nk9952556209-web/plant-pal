import { Link } from "react-router-dom";
import { ArrowRight, Leaf, BookOpen, Sparkles } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import PlantCard from "@/components/PlantCard";
import { plants } from "@/data/plants";

export default function HomePage() {
  const heroReveal = useScrollReveal();
  const featuredReveal = useScrollReveal();
  const stepsReveal = useScrollReveal();
  const ctaReveal = useScrollReveal();

  const featuredPlants = plants.filter((p) => p.difficulty === "easy").slice(0, 4);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section
        ref={heroReveal.ref}
        className={`relative overflow-hidden ${heroReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
      >
        <div className="hero-gradient">
          <div className="container py-20 md:py-32">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground leading-[1.1]">
                  Your plant journey starts here
                </h1>
                <p className="text-lg text-primary-foreground/80 max-w-md">
                  Not sure which plant to get? We'll match you with the perfect
                  green companion based on your space, light, and experience.
                </p>
                <div className="flex flex-wrap gap-3">
                  <Link
                    to="/quiz"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-background text-primary font-semibold shadow-lg transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5 active:scale-[0.97]"
                  >
                    <Sparkles className="h-4 w-4" />
                    Find My Plant
                  </Link>
                  <Link
                    to="/catalog"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border-2 border-primary-foreground/30 text-primary-foreground font-semibold transition-all duration-200 hover:bg-primary-foreground/10 active:scale-[0.97]"
                  >
                    Browse Catalog
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
              <div className="hidden md:block">
                <img
                  src="/images/hero-plants.jpg"
                  alt="Beautiful indoor plants on a shelf"
                  className="rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section
        ref={stepsReveal.ref}
        className={`py-20 ${stepsReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
      >
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            How PlantPal works
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-lg mx-auto">
            Three simple steps to find your perfect plant match
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                icon: Sparkles,
                title: "Take the quiz",
                desc: "Answer a few quick questions about your space, lighting, and experience level.",
              },
              {
                step: "02",
                icon: Leaf,
                title: "Get matched",
                desc: "We'll recommend plants that actually thrive in your specific conditions.",
              },
              {
                step: "03",
                icon: BookOpen,
                title: "Grow with confidence",
                desc: "Follow simple care guides and track your plants' progress in your dashboard.",
              },
            ].map((item, i) => (
              <div
                key={item.step}
                className={`relative p-8 rounded-2xl bg-card border border-border/60 space-y-4 ${
                  stepsReveal.isVisible ? `scroll-reveal stagger-${i + 1}` : "opacity-0"
                }`}
              >
                <span className="text-5xl font-bold text-primary/10 font-display">
                  {item.step}
                </span>
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured plants */}
      <section
        ref={featuredReveal.ref}
        className={`py-20 bg-muted/30 ${featuredReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
      >
        <div className="container">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold">
                Perfect for beginners
              </h2>
              <p className="text-muted-foreground mt-2">
                These forgiving plants are almost impossible to kill.
              </p>
            </div>
            <Link
              to="/catalog"
              className="hidden md:flex items-center gap-1 text-sm font-medium text-primary hover:underline"
            >
              View all <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {featuredPlants.map((plant, i) => (
              <div
                key={plant.id}
                className={featuredReveal.isVisible ? `scroll-reveal stagger-${i + 1}` : "opacity-0"}
              >
                <PlantCard plant={plant} />
              </div>
            ))}
          </div>
          <Link
            to="/catalog"
            className="md:hidden flex items-center justify-center gap-1 mt-6 text-sm font-medium text-primary"
          >
            View all plants <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* CTA */}
      <section
        ref={ctaReveal.ref}
        className={`py-20 ${ctaReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
      >
        <div className="container">
          <div className="hero-gradient rounded-3xl p-12 md:p-16 text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground">
              Ready to find your perfect plant?
            </h2>
            <p className="text-primary-foreground/80 max-w-md mx-auto">
              It takes less than a minute. No plant knowledge required.
            </p>
            <Link
              to="/quiz"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-background text-primary font-semibold shadow-lg transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5 active:scale-[0.97]"
            >
              <Sparkles className="h-4 w-4" />
              Take the Quiz
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
