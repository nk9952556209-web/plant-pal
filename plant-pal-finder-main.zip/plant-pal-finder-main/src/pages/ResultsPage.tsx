import { useSearchParams, Link } from "react-router-dom";
import { ArrowRight, Sparkles, RotateCcw } from "lucide-react";
import { getRecommendations, type QuizAnswers, type LightLevel, type SpaceType, type ExperienceLevel } from "@/data/plants";
import PlantCard from "@/components/PlantCard";
import { useScrollReveal } from "@/hooks/useScrollReveal";

export default function ResultsPage() {
  const [searchParams] = useSearchParams();
  const reveal = useScrollReveal();

  const answers: QuizAnswers = {
    light: (searchParams.get("light") as LightLevel) || "medium",
    space: (searchParams.get("space") as SpaceType) || "indoor",
    experience: (searchParams.get("experience") as ExperienceLevel) || "beginner",
  };

  const results = getRecommendations(answers);

  return (
    <div className="min-h-[80vh] py-12">
      <div className="container max-w-4xl">
        <div
          ref={reveal.ref}
          className={`text-center mb-12 ${reveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="h-4 w-4" />
            Your personalized results
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">
            {results.length > 0
              ? `We found ${results.length} perfect plants for you`
              : "Hmm, let's try different criteria"}
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Based on your {answers.light} light, {answers.space} space, and{" "}
            {answers.experience} experience level.
          </p>
        </div>

        {results.length > 0 ? (
          <div className="space-y-8">
            {results.map(({ plant, reasons }, i) => (
              <div
                key={plant.id}
                className={`flex flex-col md:flex-row gap-6 p-6 rounded-2xl bg-card border border-border/60 card-hover ${
                  reveal.isVisible ? `scroll-reveal stagger-${i + 1}` : "opacity-0"
                }`}
              >
                <Link to={`/plant/${plant.id}`} className="shrink-0">
                  <img
                    src={plant.image}
                    alt={plant.name}
                    className="w-full md:w-40 h-48 md:h-40 object-cover rounded-xl"
                  />
                </Link>
                <div className="flex-1 space-y-3">
                  <Link to={`/plant/${plant.id}`}>
                    <h2 className="text-display text-2xl font-bold text-foreground hover:text-primary transition-colors">
                      {plant.name}
                    </h2>
                  </Link>
                  <p className="text-sm text-muted-foreground">{plant.description}</p>
                  <div className="space-y-1">
                    <p className="text-xs font-semibold text-primary uppercase tracking-wider">
                      Why this plant?
                    </p>
                    <ul className="space-y-1">
                      {reasons.map((reason, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <span className="text-primary mt-0.5">✓</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link
                    to={`/plant/${plant.id}`}
                    className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                  >
                    View care guide <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground mb-4">
              No exact matches found. Try broadening your criteria.
            </p>
          </div>
        )}

        <div className="flex justify-center gap-4 mt-12">
          <Link
            to="/quiz"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors active:scale-[0.97]"
          >
            <RotateCcw className="h-4 w-4" /> Retake Quiz
          </Link>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium shadow-sm hover:shadow-md transition-all active:scale-[0.97]"
          >
            Browse All Plants <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
