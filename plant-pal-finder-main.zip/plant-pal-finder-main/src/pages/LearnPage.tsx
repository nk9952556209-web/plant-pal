import { Droplets, Sun, Wind, Scissors, Bug, Heart } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const tips = [
  {
    icon: Droplets,
    title: "Don't overwater",
    description: "More plants die from overwatering than underwatering. Stick your finger 1 inch into the soil — if it's dry, water. If damp, wait.",
    type: "do",
  },
  {
    icon: Sun,
    title: "Know your light",
    description: "\"Indirect light\" means near a window but not in the direct sun beam. Most houseplants burn in direct afternoon sun.",
    type: "do",
  },
  {
    icon: Wind,
    title: "Give them drainage",
    description: "Always use pots with drainage holes. Water sitting at the bottom causes root rot — the silent plant killer.",
    type: "do",
  },
  {
    icon: Scissors,
    title: "Trim dead leaves",
    description: "Yellow or brown leaves won't recover. Remove them so the plant can focus energy on healthy growth.",
    type: "do",
  },
  {
    icon: Bug,
    title: "Check for pests regularly",
    description: "Look under leaves once a week. Tiny webs, sticky residue, or small dots might mean unwanted visitors.",
    type: "do",
  },
  {
    icon: Heart,
    title: "Be patient",
    description: "Plants adjust to new environments. If your new plant drops a leaf or two, don't panic — it's just settling in.",
    type: "do",
  },
];

const donts = [
  "Water on a strict schedule — always check the soil first",
  "Move your plant around constantly — pick a spot and let it settle",
  "Use ice cubes to water (yes, some people do this!) — use room-temperature water",
  "Ignore yellowing leaves — they're telling you something",
  "Put every plant in direct sunlight — many prefer shade",
  "Fertilize in winter — most plants are dormant and don't need food",
];

export default function LearnPage() {
  const heroReveal = useScrollReveal();
  const tipsReveal = useScrollReveal();
  const dontsReveal = useScrollReveal();

  return (
    <div className="py-12">
      <div className="container max-w-4xl">
        {/* Header */}
        <div
          ref={heroReveal.ref}
          className={`text-center mb-16 ${heroReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-3">New to Plants?</h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-lg">
            No green thumb required. Here's everything you need to know
            to keep your first plant alive and thriving.
          </p>
        </div>

        {/* Tips */}
        <div ref={tipsReveal.ref} className="mb-16">
          <h2
            className={`text-2xl font-bold mb-6 ${tipsReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
          >
            ✅ Do's — Simple habits for healthy plants
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {tips.map((tip, i) => (
              <div
                key={tip.title}
                className={`p-5 rounded-2xl bg-card border border-border/60 space-y-2 card-hover ${
                  tipsReveal.isVisible ? `scroll-reveal stagger-${Math.min(i + 1, 5)}` : "opacity-0"
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                    <tip.icon className="h-4 w-4 text-primary" />
                  </div>
                  <h3 className="font-semibold">{tip.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground">{tip.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Don'ts */}
        <div ref={dontsReveal.ref}>
          <h2
            className={`text-2xl font-bold mb-6 ${dontsReveal.isVisible ? "scroll-reveal" : "opacity-0"}`}
          >
            ❌ Don'ts — Common beginner mistakes
          </h2>
          <div className="space-y-3">
            {donts.map((dont, i) => (
              <div
                key={i}
                className={`flex items-start gap-3 p-4 rounded-xl bg-red-50/50 border border-red-200/40 ${
                  dontsReveal.isVisible ? `scroll-reveal stagger-${Math.min(i + 1, 5)}` : "opacity-0"
                }`}
              >
                <span className="text-destructive font-bold shrink-0 mt-0.5">✗</span>
                <p className="text-sm text-foreground/80">{dont}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
