export interface Plant {
  id: string;
  name: string;
  botanicalName: string;
  image: string;
  lightRequirement: "low" | "medium" | "bright";
  waterFrequency: string;
  waterDays: number;
  difficulty: "easy" | "medium" | "hard";
  suitableSpace: ("indoor" | "balcony" | "outdoor")[];
  careInstructions: {
    watering: string;
    sunlight: string;
    soil: string;
    temperature: string;
  };
  commonMistakes: string[];
  growthExpectations: string;
  description: string;
  tags: string[];
}

export const plants: Plant[] = [
  {
    id: "snake-plant",
    name: "Snake Plant",
    botanicalName: "Dracaena trifasciata",
    image: "/images/snake-plant.jpg",
    lightRequirement: "low",
    waterFrequency: "Every 2-3 weeks",
    waterDays: 18,
    difficulty: "easy",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Let the soil dry out completely between waterings. In winter, water even less — once a month is fine.",
      sunlight: "Tolerates low light but grows faster in indirect bright light. Avoid direct afternoon sun.",
      soil: "Well-draining cactus or succulent mix. Add perlite for extra drainage.",
      temperature: "60-85°F (15-29°C). Keep away from cold drafts.",
    },
    commonMistakes: [
      "Overwatering — this is the #1 killer. When in doubt, don't water.",
      "Using pots without drainage holes",
      "Placing in complete darkness (it tolerates low light, not no light)",
    ],
    growthExpectations: "Slow grower. Expect 2-4 new leaves per year. Can reach 3-4 feet tall over several years.",
    description: "The ultimate beginner plant. Nearly indestructible, purifies air, and looks architectural. Perfect if you forget to water.",
    tags: ["air-purifying", "low-maintenance", "drought-tolerant"],
  },
  {
    id: "pothos",
    name: "Golden Pothos",
    botanicalName: "Epipremnum aureum",
    image: "/images/pothos.jpg",
    lightRequirement: "low",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 10,
    difficulty: "easy",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Water when the top inch of soil feels dry. Leaves will droop slightly when thirsty — a helpful built-in reminder.",
      sunlight: "Thrives in low to medium indirect light. Variegation is more pronounced in brighter light.",
      soil: "Standard potting mix works great. Not fussy about soil.",
      temperature: "65-85°F (18-29°C). Average room temperature is perfect.",
    },
    commonMistakes: [
      "Letting it sit in soggy soil — always drain excess water",
      "Expecting it to trail in very low light (it will grow slowly and leggy)",
      "Not pruning — regular trims keep it bushy and healthy",
    ],
    growthExpectations: "Fast grower! Trails can grow 6-10 feet long. Trim and propagate easily in water.",
    description: "A trailing vine that's almost impossible to kill. Gorgeous cascading from shelves or hanging baskets. Tells you when it's thirsty.",
    tags: ["trailing", "air-purifying", "easy-propagation"],
  },
  {
    id: "spider-plant",
    name: "Spider Plant",
    botanicalName: "Chlorophytum comosum",
    image: "/images/spider-plant.jpg",
    lightRequirement: "medium",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 10,
    difficulty: "easy",
    suitableSpace: ["indoor", "balcony"],
    careInstructions: {
      watering: "Keep soil lightly moist but not waterlogged. Reduce watering in winter.",
      sunlight: "Bright, indirect light is ideal. Can handle some direct morning sun. Avoid harsh afternoon sun.",
      soil: "Well-draining general potting mix. Repot when roots start poking out.",
      temperature: "55-80°F (13-27°C). Very adaptable to different temperatures.",
    },
    commonMistakes: [
      "Ignoring brown leaf tips — usually caused by tap water chemicals. Try filtered water.",
      "Not giving it enough room to grow its baby spiderettes",
      "Over-fertilizing — feed only during spring and summer",
    ],
    growthExpectations: "Moderate grower. Produces adorable 'babies' (spiderettes) that dangle from the mother plant. Easy to propagate.",
    description: "A cheerful, arching plant that produces cute baby plantlets. Great hanging plant and one of the best air purifiers.",
    tags: ["air-purifying", "pet-friendly", "easy-propagation"],
  },
  {
    id: "peace-lily",
    name: "Peace Lily",
    botanicalName: "Spathiphyllum",
    image: "/images/peace-lily.jpg",
    lightRequirement: "low",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 10,
    difficulty: "easy",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Water when top inch of soil is dry. It dramatically droops when thirsty but bounces right back after watering.",
      sunlight: "Low to medium indirect light. One of the best plants for dark rooms. No direct sun.",
      soil: "Rich, well-draining potting mix. Likes to be slightly moist.",
      temperature: "65-80°F (18-27°C). Keep away from cold drafts and heating vents.",
    },
    commonMistakes: [
      "Panicking when it droops — it's just thirsty, not dying!",
      "Placing in direct sunlight (leaves will burn)",
      "Forgetting to wipe dust off the large leaves",
    ],
    growthExpectations: "Moderate grower. Produces elegant white flowers in the right conditions. Can reach 1-4 feet tall.",
    description: "Elegant white blooms and glossy dark leaves. Dramatically tells you when it needs water by drooping — then perks right back up.",
    tags: ["flowering", "air-purifying", "low-light"],
  },
  {
    id: "aloe-vera",
    name: "Aloe Vera",
    botanicalName: "Aloe barbadensis miller",
    image: "/images/aloe-vera.jpg",
    lightRequirement: "bright",
    waterFrequency: "Every 2-3 weeks",
    waterDays: 18,
    difficulty: "easy",
    suitableSpace: ["indoor", "balcony"],
    careInstructions: {
      watering: "Soak the soil thoroughly, then let it dry out completely. Less is more — overwatering causes root rot.",
      sunlight: "Bright, indirect light. Can handle some direct sun but may turn brown if it's too intense.",
      soil: "Cactus/succulent mix is perfect. Must have excellent drainage.",
      temperature: "55-80°F (13-27°C). Bring indoors if temperatures drop below 50°F.",
    },
    commonMistakes: [
      "Watering too frequently — this succulent stores water in its leaves",
      "Using regular potting soil instead of cactus mix",
      "Not providing enough light (it gets leggy and pale)",
    ],
    growthExpectations: "Slow to moderate grower. Produces pups (baby plants) at the base. Gel from mature leaves has soothing properties.",
    description: "A useful succulent with healing gel inside its leaves. Low-maintenance, architectural, and doubles as a natural first-aid kit.",
    tags: ["succulent", "medicinal", "drought-tolerant"],
  },
  {
    id: "rubber-plant",
    name: "Rubber Plant",
    botanicalName: "Ficus elastica",
    image: "/images/rubber-plant.jpg",
    lightRequirement: "medium",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 12,
    difficulty: "medium",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Water when top 1-2 inches of soil are dry. Mist leaves occasionally for humidity.",
      sunlight: "Medium to bright indirect light. Dark-leaved varieties tolerate lower light.",
      soil: "Well-draining potting mix with perlite. Doesn't like sitting in water.",
      temperature: "60-80°F (15-27°C). Doesn't like sudden temperature changes.",
    },
    commonMistakes: [
      "Moving it around too much — pick a spot and let it acclimate",
      "Overwatering in winter when growth slows",
      "Not cleaning the large, glossy leaves (they collect dust)",
    ],
    growthExpectations: "Can grow quite tall indoors — up to 6-10 feet. Prune to control height and encourage branching.",
    description: "Bold, glossy leaves in deep burgundy or dark green. A statement plant that fills corners beautifully and grows impressively tall.",
    tags: ["statement", "air-purifying", "tall"],
  },
  {
    id: "zz-plant",
    name: "ZZ Plant",
    botanicalName: "Zamioculcas zamiifolia",
    image: "/images/zz-plant.jpg",
    lightRequirement: "low",
    waterFrequency: "Every 2-3 weeks",
    waterDays: 20,
    difficulty: "easy",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Very drought tolerant. Water only when soil is completely dry. Underground rhizomes store water.",
      sunlight: "Tolerates low light exceptionally well. Also happy in medium indirect light.",
      soil: "Well-draining mix. Standard potting soil with added perlite works well.",
      temperature: "65-85°F (18-29°C). Very adaptable.",
    },
    commonMistakes: [
      "Watering on a schedule instead of checking soil — this plant hates wet feet",
      "Expecting fast growth — it's naturally slow",
      "Not knowing the sap can irritate skin — wash hands after handling",
    ],
    growthExpectations: "Very slow grower. New stalks emerge from soil level. Can reach 2-3 feet. Virtually indestructible.",
    description: "Glossy, waxy leaves on arching stems. Thrives on neglect. Perfect for offices, bathrooms, or anywhere you might forget about a plant.",
    tags: ["low-maintenance", "drought-tolerant", "office-friendly"],
  },
  {
    id: "monstera",
    name: "Monstera",
    botanicalName: "Monstera deliciosa",
    image: "/images/monstera.jpg",
    lightRequirement: "medium",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 10,
    difficulty: "medium",
    suitableSpace: ["indoor"],
    careInstructions: {
      watering: "Water when top 2 inches of soil are dry. Likes humidity — mist regularly or use a pebble tray.",
      sunlight: "Bright, indirect light for the famous split leaves. Too little light = no fenestrations.",
      soil: "Chunky, well-draining mix. Add orchid bark and perlite to standard potting soil.",
      temperature: "65-85°F (18-29°C). Loves humidity above 50%.",
    },
    commonMistakes: [
      "Not providing a moss pole or support for climbing",
      "Expecting split leaves immediately — young plants have solid leaves",
      "Too little light — it needs brightness for those iconic holes",
    ],
    growthExpectations: "Moderate to fast grower with good light. Leaves get larger and more fenestrated with age. Can become quite large.",
    description: "The iconic Swiss cheese plant with dramatic split leaves. A true showstopper that brings tropical vibes to any room.",
    tags: ["tropical", "statement", "trending"],
  },
  {
    id: "jade-plant",
    name: "Jade Plant",
    botanicalName: "Crassula ovata",
    image: "/images/jade-plant.jpg",
    lightRequirement: "bright",
    waterFrequency: "Every 2-3 weeks",
    waterDays: 18,
    difficulty: "easy",
    suitableSpace: ["indoor", "balcony"],
    careInstructions: {
      watering: "Let soil dry completely between waterings. Thick leaves store water. Water less in winter.",
      sunlight: "Loves bright light, including some direct sun. At least 4 hours of bright light daily.",
      soil: "Succulent/cactus mix with excellent drainage. Terracotta pots are ideal.",
      temperature: "55-75°F (13-24°C). Tolerates dry air well.",
    },
    commonMistakes: [
      "Overwatering — the most common cause of death for jade plants",
      "Not providing enough light (becomes leggy and weak)",
      "Using plastic pots that retain too much moisture",
    ],
    growthExpectations: "Slow but long-lived — can survive for decades! Develops a thick, tree-like trunk over time. Can bloom with proper care.",
    description: "A charming succulent with thick, oval leaves on woody stems. Symbol of good luck and prosperity. Can live for generations.",
    tags: ["succulent", "long-lived", "drought-tolerant"],
  },
  {
    id: "herbs-basil",
    name: "Sweet Basil",
    botanicalName: "Ocimum basilicum",
    image: "/images/basil.jpg",
    lightRequirement: "bright",
    waterFrequency: "Every 2-3 days",
    waterDays: 3,
    difficulty: "medium",
    suitableSpace: ["balcony", "outdoor"],
    careInstructions: {
      watering: "Keep soil consistently moist but not soggy. Water at the base, not on leaves.",
      sunlight: "Full sun — needs 6-8 hours of direct sunlight daily. A sunny windowsill or balcony is essential.",
      soil: "Rich, well-draining potting mix. Benefits from compost or organic fertilizer.",
      temperature: "70-85°F (21-29°C). Very frost sensitive — bring inside if cold.",
    },
    commonMistakes: [
      "Not pinching off flower buds — flowering makes leaves bitter",
      "Harvesting from the bottom instead of pinching from the top",
      "Not enough sunlight — it needs a LOT of sun",
    ],
    growthExpectations: "Fast grower in warm conditions. Harvest regularly to encourage bushy growth. Annual plant — replace each season.",
    description: "Fresh basil right from your balcony! Nothing beats the taste of homegrown herbs. Pinch regularly for bushier growth and endless pesto.",
    tags: ["edible", "herb", "aromatic"],
  },
  {
    id: "lavender",
    name: "Lavender",
    botanicalName: "Lavandula",
    image: "/images/lavender.jpg",
    lightRequirement: "bright",
    waterFrequency: "Every 1-2 weeks",
    waterDays: 12,
    difficulty: "medium",
    suitableSpace: ["balcony", "outdoor"],
    careInstructions: {
      watering: "Prefers to dry out between waterings. Drought tolerant once established. Avoid wet feet.",
      sunlight: "Full sun — at least 6 hours of direct sunlight. More sun = more flowers and fragrance.",
      soil: "Sandy, alkaline, well-draining soil. Add gravel or sand to improve drainage.",
      temperature: "45-80°F (7-27°C). Fairly cold hardy but protect from harsh winters.",
    },
    commonMistakes: [
      "Overwatering — this Mediterranean plant likes it dry",
      "Rich soil — lavender actually prefers poor, lean soil",
      "Not pruning after flowering — leads to woody, sparse growth",
    ],
    growthExpectations: "Moderate grower. Blooms in late spring to summer. Can last many years with proper pruning. Incredibly fragrant.",
    description: "Fragrant purple blooms that attract butterflies and bees. Calming scent, beautiful color, and useful for cooking, sachets, and relaxation.",
    tags: ["fragrant", "flowering", "pollinator-friendly"],
  },
  {
    id: "boston-fern",
    name: "Boston Fern",
    botanicalName: "Nephrolepis exaltata",
    image: "/images/boston-fern.jpg",
    lightRequirement: "medium",
    waterFrequency: "Every 3-5 days",
    waterDays: 4,
    difficulty: "medium",
    suitableSpace: ["indoor", "balcony"],
    careInstructions: {
      watering: "Keep soil consistently moist. Loves humidity — mist daily or place on a pebble tray with water.",
      sunlight: "Indirect light. Avoid direct sun which scorches the fronds. Bright bathroom = heaven.",
      soil: "Rich, peat-based potting mix that retains some moisture.",
      temperature: "60-75°F (15-24°C). Loves humidity above 50%.",
    },
    commonMistakes: [
      "Not enough humidity — dry air causes browning and leaf drop",
      "Direct sunlight burns the delicate fronds",
      "Giving up too quickly when it drops leaves (it's adjusting!)",
    ],
    growthExpectations: "Fast grower with proper care. Lush, arching fronds can reach 2-3 feet. Stunning in hanging baskets.",
    description: "Lush, cascading green fronds that bring a soft, woodland feel indoors. The classic bathroom plant — loves steam and humidity.",
    tags: ["humidity-loving", "air-purifying", "hanging"],
  },
];

export type LightLevel = "low" | "medium" | "bright";
export type SpaceType = "indoor" | "balcony" | "outdoor";
export type ExperienceLevel = "beginner" | "intermediate";
export type Difficulty = "easy" | "medium" | "hard";

export interface QuizAnswers {
  light: LightLevel;
  space: SpaceType;
  experience: ExperienceLevel;
}

export function getRecommendations(answers: QuizAnswers): { plant: Plant; reasons: string[] }[] {
  const scored = plants.map((plant) => {
    let score = 0;
    const reasons: string[] = [];

    // Light match
    if (plant.lightRequirement === answers.light) {
      score += 3;
      reasons.push(`Matches your ${answers.light} light conditions perfectly`);
    } else if (
      (answers.light === "medium" && plant.lightRequirement === "low") ||
      (answers.light === "bright" && plant.lightRequirement === "medium")
    ) {
      score += 1;
      reasons.push(`Can adapt to your ${answers.light} light`);
    }

    // Space match
    if (plant.suitableSpace.includes(answers.space)) {
      score += 3;
      reasons.push(`Great for ${answers.space} spaces`);
    }

    // Experience match
    if (answers.experience === "beginner" && plant.difficulty === "easy") {
      score += 3;
      reasons.push("Perfect for beginners — very forgiving");
    } else if (answers.experience === "beginner" && plant.difficulty === "medium") {
      score += 1;
      reasons.push("Manageable for beginners with a little attention");
    } else if (answers.experience === "intermediate") {
      score += 2;
      reasons.push("A good match for your experience level");
    }

    return { plant, score, reasons };
  });

  return scored
    .filter((s) => s.score >= 4)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(({ plant, reasons }) => ({ plant, reasons }));
}
