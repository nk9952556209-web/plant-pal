import { Link } from "react-router-dom";
import { Droplets, Sun, Gauge } from "lucide-react";
import type { Plant } from "@/data/plants";

const difficultyColor = {
  easy: "bg-green-100 text-green-800",
  medium: "bg-amber-100 text-amber-800",
  hard: "bg-red-100 text-red-800",
};

const lightIcon = {
  low: "☁️",
  medium: "⛅",
  bright: "☀️",
};

export default function PlantCard({ plant }: { plant: Plant }) {
  return (
    <Link
      to={`/plant/${plant.id}`}
      className="group block rounded-2xl bg-card border border-border/60 overflow-hidden card-hover"
    >
      <div className="aspect-[4/5] overflow-hidden bg-muted">
        <img
          src={plant.image}
          alt={plant.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
      </div>
      <div className="p-4 space-y-3">
        <div>
          <h3 className="text-display text-lg font-semibold text-foreground leading-tight">
            {plant.name}
          </h3>
          <p className="text-xs text-muted-foreground italic">{plant.botanicalName}</p>
        </div>

        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <span>{lightIcon[plant.lightRequirement]}</span>
            <span className="capitalize">{plant.lightRequirement}</span>
          </span>
          <span className="flex items-center gap-1">
            <Droplets className="h-3 w-3" />
            {plant.waterFrequency}
          </span>
        </div>

        <span
          className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${difficultyColor[plant.difficulty]}`}
        >
          {plant.difficulty}
        </span>
      </div>
    </Link>
  );
}
