import { Leaf } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-muted/40 py-12">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Leaf className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-display text-lg font-bold text-foreground">PlantPal</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Helping you grow confidence, one plant at a time.
          </p>
        </div>
      </div>
    </footer>
  );
}
