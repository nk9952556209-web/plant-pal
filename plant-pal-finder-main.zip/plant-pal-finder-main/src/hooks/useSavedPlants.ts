import { useState, useEffect, useCallback } from "react";

export interface SavedPlant {
  plantId: string;
  savedAt: string;
  lastWatered: string | null;
  status: "healthy" | "needs-attention";
  tasksCompleted: string[]; // dates of completed watering
}

const STORAGE_KEY = "plantpal-saved-plants";

function loadSaved(): SavedPlant[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function persist(plants: SavedPlant[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(plants));
}

export function useSavedPlants() {
  const [savedPlants, setSavedPlants] = useState<SavedPlant[]>(loadSaved);

  useEffect(() => {
    persist(savedPlants);
  }, [savedPlants]);

  const savePlant = useCallback((plantId: string) => {
    setSavedPlants((prev) => {
      if (prev.some((p) => p.plantId === plantId)) return prev;
      return [
        ...prev,
        {
          plantId,
          savedAt: new Date().toISOString(),
          lastWatered: null,
          status: "healthy",
          tasksCompleted: [],
        },
      ];
    });
  }, []);

  const removePlant = useCallback((plantId: string) => {
    setSavedPlants((prev) => prev.filter((p) => p.plantId !== plantId));
  }, []);

  const markWatered = useCallback((plantId: string) => {
    setSavedPlants((prev) =>
      prev.map((p) =>
        p.plantId === plantId
          ? {
              ...p,
              lastWatered: new Date().toISOString(),
              status: "healthy" as const,
              tasksCompleted: [...p.tasksCompleted, new Date().toISOString()],
            }
          : p
      )
    );
  }, []);

  const isPlantSaved = useCallback(
    (plantId: string) => savedPlants.some((p) => p.plantId === plantId),
    [savedPlants]
  );

  return { savedPlants, savePlant, removePlant, markWatered, isPlantSaved };
}
